#
# Copyright (c) 2013 Juniper Networks, Inc. All rights reserved.
#

"""
The main modules in this package are:
    * libpartition
"""
