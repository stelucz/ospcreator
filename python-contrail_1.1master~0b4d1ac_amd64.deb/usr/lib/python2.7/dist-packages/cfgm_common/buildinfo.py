build_info = "{\"build-info\" : [{\"build-version\" : \"4.1.0.0\", \"build-time\" : \"2017-09-20 11:42:36.433775\", \"build-user\" : \"ubuntu\", \"build-hostname\" : \"buildtest\", ";
